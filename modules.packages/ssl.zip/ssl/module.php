<?php
	use fruithost\ModuleInterface;
	
	class SSL extends ModuleInterface {
		public function init() {
			
		}
	}
?>