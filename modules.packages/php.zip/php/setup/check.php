<?php
	if(!is_readable(HOST_PATH)) {
		printf('<br />path <strong>%s</strong> can\'t be accessed!', HOST_PATH);		
	}
?>