<?php
	use fruithost\ModuleInterface;
	
	class Logfiles extends ModuleInterface {
		public function init() {
			
		}
	}
?>