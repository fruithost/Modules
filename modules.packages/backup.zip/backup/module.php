<?php
	use fruithost\ModuleInterface;
	
	class Backup extends ModuleInterface {
		public function init() {
			
		}
	}
?>