<?php
	use fruithost\Database;
?>