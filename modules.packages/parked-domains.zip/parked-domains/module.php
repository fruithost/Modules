<?php
	use fruithost\ModuleInterface;
	
	class ParkedDomains extends ModuleInterface {
		public function init() {
			
		}
	}
?>