# Config
This module allows you to edit and view the configuration files.

## Support us! ![Sponsors](https://img.shields.io/github/sponsors/fruithost?style=social)
Donations are an important contribution to the development of OpenSource projects. With your donation you can help us to advance our project. Your support enables us to support the programming.

Be a team-player, all feedbacks of our donations will have the priority. We will build the site for **YOU**!

[![PAYPAL]](https://paypal.me/debitdirect) [![PATREON]](https://www.patreon.com/fruithost) [![GITHUB]](https://github.com/sponsors/fruithost)

![BANK]

[GITHUB]: https://img.shields.io/badge/GitHub-%24?style=for-the-badge&logo=github&color=%230d1117
[PAYPAL]: https://img.shields.io/badge/PayPal-%24?style=for-the-badge&logo=paypal&color=%23169BD7
[PATREON]: https://img.shields.io/badge/PATREON-%24?style=for-the-badge&logo=patreon&color=%23F96854
[BANK]: https://github.com/fruithost/Documentation/blob/main/Images/donation_bank.png?raw=true