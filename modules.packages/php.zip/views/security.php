<div class="container">
	<div class="form-group row">
		<label for="expose_php" class="col-4 col-form-label col-form-label-sm">expose_php</label>
		<div class="col-8">
			<select name="expose_php" class="form-control">
				<option value="On">On</option>
				<option value="Off">Off</option>
			</select>
		</div>
		<div class="text-muted ml-4">
			Description of expose_php
		</div>
	</div>
	<div class="form-group row">
		<label for="enable_dl" class="col-4 col-form-label col-form-label-sm">enable_dl</label>
		<div class="col-8">
			<select name="enable_dl" class="form-control">
				<option value="On">On</option>
				<option value="Off">Off</option>
			</select>
		</div>
		<div class="text-muted ml-4">
			Description of enable_dl
		</div>
	</div>
	<div class="form-group row">
		<label for="file_uploads" class="col-4 col-form-label col-form-label-sm">file_uploads</label>
		<div class="col-8">
			<select name="file_uploads" class="form-control">
				<option value="On">On</option>
				<option value="Off">Off</option>
			</select>
		</div>
		<div class="text-muted ml-4">
			Description of file_uploads
		</div>
	</div>
	<div class="form-group row">
		<label for="allow_url_fopen" class="col-4 col-form-label col-form-label-sm">allow_url_fopen</label>
		<div class="col-8">
			<select name="allow_url_fopen" class="form-control">
				<option value="On">On</option>
				<option value="Off">Off</option>
			</select>
		</div>
		<div class="text-muted ml-4">
			Description of allow_url_fopen
		</div>
	</div>
	<div class="form-group row">
		<label for="allow_url_include" class="col-4 col-form-label col-form-label-sm">allow_url_include</label>
		<div class="col-8">
			<select name="allow_url_include" class="form-control">
				<option value="On">On</option>
				<option value="Off">Off</option>
			</select>
		</div>
		<div class="text-muted ml-4">
			Description of allow_url_include
		</div>
	</div>
	<div class="form-group row">
		<label for="mail.add_x_header" class="col-4 col-form-label col-form-label-sm">mail.add_x_header</label>
		<div class="col-8">
			<select name="mail.add_x_header" class="form-control">
				<option value="On">On</option>
				<option value="Off">Off</option>
			</select>
		</div>
		<div class="text-muted ml-4">
			Description of mail.add_x_header
		</div>
	</div>
</div>