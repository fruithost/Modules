# Changelog
## `1.0.1` - 06.09.2024
- Add module information (screenshots, readme, changelog)

## `1.0.0` - 02.09.2024
- Fixing file handling
- Adding new config files

## `1.0.0` - 31.08.2024
- Fixing module permissions
- Hiding TextArea

## `1.0.0` - 23.08.2024
- Saving files

## `1.0.0` - 19.08.2024
Implement the basic module.
- Fix some bugs