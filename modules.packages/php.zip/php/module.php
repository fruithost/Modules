<?php
	use fruithost\ModuleInterface;
	
	class PHP extends ModuleInterface {
		public function init() {
			
		}
	}
?>