<?php
	use fruithost\ModuleInterface;
	
	class Cronjob extends ModuleInterface {
		public function init() {
			
		}
	}
?>