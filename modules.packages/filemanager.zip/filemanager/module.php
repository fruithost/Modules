<?php
	use fruithost\ModuleInterface;
	
	class FileManager extends ModuleInterface {
		public function init() {
			
		}
	}
?>