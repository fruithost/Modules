<?php
	use fruithost\ModuleInterface;
	
	class PHPMyAdmin extends ModuleInterface {
		public function init() {
			
		}
	}
?>