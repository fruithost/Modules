<?php
	use fruithost\ModuleInterface;
	
	class ProtectedDirectorys extends ModuleInterface {
		public function init() {
			
		}
	}
?>