<?php
	use fruithost\ModuleInterface;
	
	class FAQ extends ModuleInterface {
		public function init() {
			
		}
	}
?>