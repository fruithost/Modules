# Changelog
## `1.5.4` - 06.09.2024
- Add module information (screenshots, readme, changelog)

## `1.5.3` - 10.08.2024
- Adding module checks
- Fix some bugs

## `1.5.1` - 15.11.2023
- Upgrade output to Bootstrap 5
- Fix some new Module-API calls

## `1.5.1` - 10.11.2023
- update Module for new Module-API

## `1.0.0` - 08.11.2023
- Adding greek language

## `1.0.0` - 05.11.2023
- Fix language

## `1.0.0` - 03.06.2023
- Fix path errors

## `1.0.0` - 16.05.2019
- Fix HTML table
- beautify output

## `1.0.0` - 13.05.2019
- Adding database prefix from config

## `1.0.0` - 12.05.2019
- Adding module description

## `1.0.0` - 11.05.2019
- Adding time format from user settings

## `1.0.0` - 05.05.2019
Implement the basic module.