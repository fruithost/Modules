<?php
	use fruithost\ModuleInterface;
	
	class DNS extends ModuleInterface {
		public function init() {
			
		}
	}
?>