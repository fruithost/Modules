<?php
	use fruithost\ModuleInterface;
	
	class Theme extends ModuleInterface {
		public function init() {
			/*$this->addFilter('theme_name', function($name) {
				return $name;
			});*/
		}
	}
?>