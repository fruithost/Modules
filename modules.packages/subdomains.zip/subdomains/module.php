<?php
	use fruithost\ModuleInterface;
	
	class Subdomains extends ModuleInterface {
		public function init() {
			
		}
	}
?>