<?php
	use fruithost\ModuleInterface;
	
	class FTP extends ModuleInterface {
		public function init() {
			
		}
	}
?>