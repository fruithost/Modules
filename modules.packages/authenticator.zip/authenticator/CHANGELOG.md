# Changelog
## `1.0.2` - 05.09.2024
- Add module information (screenshots, readme, changelog)

## `1.0.1` - 10.08.2024
- Adding a Module check
- Fix some bugs
- reinstall procedure on errors/checks

## `1.0.0` - 06.08.2024
Implement the basic module for 2FA via an authenticator app.